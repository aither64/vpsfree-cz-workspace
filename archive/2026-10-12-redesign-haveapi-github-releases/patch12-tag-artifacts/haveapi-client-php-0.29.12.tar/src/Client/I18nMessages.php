<?php

// This file is generated from i18n/haveapi.yml.
// Do not edit it manually; manual changes will be overwritten.
// Update i18n/haveapi.yml and run bundle exec rake i18n:update.

namespace HaveAPI\Client;

final class I18nMessages
{
    public const MESSAGES = [
        'en' => [
            'authentication' => [
                'callback_failed' => 'Callback %{callback} failed: %{error}',
                'callback_invalid_return' => 'The callback must return an array or \'stop\'',
                'callback_required' => 'Callback %{callback} must be implemented',
                'invalid_credentials' => 'Invalid credentials',
                'invalid_oauth2_pkce_verifier' => 'Invalid OAuth2 PKCE verifier',
                'invalid_oauth2_state' => 'Invalid OAuth2 state',
                'mfa_required' => 'Multi-factor authentication support must be implemented',
                'multistep_callback_required' => 'Add a callback to handle multi-step authentication',
                'oauth2_access_token_required' => 'The access_token option must be provided',
                'oauth2_not_configured' => 'OAuth2 authentication is not configured',
                'oauth2_revoke_failed' => 'Unable to revoke access token, HTTP %{status}',
                'token_request_failed' => 'Unable to request token: %{message}',
                'token_revoke_failed' => 'Unable to revoke token: %{message}',
                'token_step_failed' => 'Authentication step \'%{action}\' failed: %{message}',
                'unsupported_auth_action' => 'Unsupported authentication action \'%{action}\'',
            ],
            'errors' => [
                'access_forbidden' => 'Access forbidden.
Bad username or password? Insufficient permissions?',
                'action_failed' => 'Action %{action} failed: %{message}',
                'fatal_api_error' => 'Fatal API error: %{error}',
                'input_parameters_not_valid' => 'Input parameters are not valid',
                'input_parameters_not_valid_for_action' => 'Input parameters are not valid for action \'%{action}\'',
                'invalid_input_parameters' => 'Invalid input parameters',
                'uncancelable_action' => 'Action with state #%{id} cannot be cancelled',
                'unresolved_arguments' => 'Unable to execute action \'%{action}\': unresolved path arguments',
            ],
            'validation' => [
                'cannot_be_null' => 'cannot be null',
                'invalid_boolean' => 'not a valid boolean',
                'invalid_datetime' => 'not in ISO 8601 format',
                'invalid_float' => 'not a valid float',
                'invalid_input_layout' => 'invalid input layout',
                'invalid_integer' => 'not a valid integer',
                'invalid_resource_id' => 'not a valid resource ID',
                'invalid_string' => 'not a valid string',
                'required_parameter_missing' => 'required parameter is missing',
                'validation_failed' => 'validation failed',
                'validation_failed_with_errors' => 'validation failed: %{errors}',
            ],
        ],
        'cs' => [
            'authentication' => [
                'callback_failed' => 'Callback %{callback} selhal: %{error}',
                'callback_invalid_return' => 'Callback musí vrátit pole nebo \'stop\'',
                'callback_required' => 'Je potřeba implementovat callback %{callback}',
                'invalid_credentials' => 'Neplatné přihlašovací údaje',
                'invalid_oauth2_pkce_verifier' => 'Neplatný OAuth2 PKCE verifier',
                'invalid_oauth2_state' => 'Neplatný parametr OAuth2 state',
                'mfa_required' => 'Klient musí implementovat vícefaktorové ověření',
                'multistep_callback_required' => 'Je potřeba přidat callback pro zpracování vícefázové autentizace',
                'oauth2_access_token_required' => 'Volba access_token musí být zadána',
                'oauth2_not_configured' => 'OAuth2 autentizace není nastavena',
                'oauth2_revoke_failed' => 'Přístupový token se nepodařilo zneplatnit, HTTP %{status}',
                'token_request_failed' => 'Token se nepodařilo vyžádat: %{message}',
                'token_revoke_failed' => 'Token se nepodařilo zneplatnit: %{message}',
                'token_step_failed' => 'Krok autentizace \'%{action}\' se nezdařil: %{message}',
                'unsupported_auth_action' => 'Nepodporovaná autentizační akce \'%{action}\'',
            ],
            'errors' => [
                'access_forbidden' => 'Přístup odepřen.
Chybné uživatelské jméno nebo heslo? Nedostatečná oprávnění?',
                'action_failed' => 'Akce %{action} se nezdařila: %{message}',
                'fatal_api_error' => 'Závažná chyba API: %{error}',
                'input_parameters_not_valid' => 'Vstupní parametry jsou neplatné',
                'input_parameters_not_valid_for_action' => 'Vstupní parametry pro akci \'%{action}\' jsou neplatné',
                'invalid_input_parameters' => 'Neplatné vstupní parametry',
                'uncancelable_action' => 'Akci se stavem #%{id} nelze zrušit',
                'unresolved_arguments' => 'Akci \'%{action}\' nelze spustit: chybí argumenty cesty',
            ],
            'validation' => [
                'cannot_be_null' => 'nesmí být null',
                'invalid_boolean' => 'není platná pravdivostní hodnota',
                'invalid_datetime' => 'není ve formátu ISO 8601',
                'invalid_float' => 'není platné desetinné číslo',
                'invalid_input_layout' => 'neplatná struktura vstupu',
                'invalid_integer' => 'není platné celé číslo',
                'invalid_resource_id' => 'neplatné ID zdroje',
                'invalid_string' => 'není platný řetězec',
                'required_parameter_missing' => 'chybí povinný parametr',
                'validation_failed' => 'validace selhala',
                'validation_failed_with_errors' => 'validace selhala: %{errors}',
            ],
        ],
    ];
}
